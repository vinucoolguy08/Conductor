package com.netflix.conductor.azureblob;

import com.netflix.conductor.core.config.SystemPropertiesConfiguration;

public class SystemPropertiesAzureBlobConfiguration extends SystemPropertiesConfiguration implements AzureBlobConfiguration {
}
