## Conductor: gRPC Go client generation
At the moment, the generation of the go client is manual.
In order to generate the Go gRPC client, run: 
```
make proto
```
This should update the folder `client/gogrpc/conductor` if any changes.
